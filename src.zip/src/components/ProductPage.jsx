// src/pages/ProductPage.jsx
import React from "react";
import { useParams } from "react-router-dom";
import ProductDetails from "../components/productDetails";

import products from "../data/products.js";

export default function ProductPage() {
  const { id } = useParams();
  const product = products.find((p) => p.id === id);

  return (
    <div>
      {product ? <ProductDetails product={product} /> : <h2>Product not found</h2>}
    </div>
  );
}
