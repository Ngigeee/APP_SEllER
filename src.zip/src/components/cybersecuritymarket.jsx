// ================================
// File: Marketplace.jsx
// ================================
import React, { useMemo, useState, useEffect } from "react";
import "./cybersecuritymarket.css";

// Mock data — in a real app, fetch this from your API
const MOCK_ITEMS = [
  {
    id: "w1",
    type: "full-website",
    title: "SaaS Landing (Next.js)",
    description: "Modern SaaS homepage with pricing, auth placeholders, and blog.",
    tags: ["Next.js", "Tailwind", "SEO"],
    language: ["React"],
    sizeMB: 18,
    price: 49,
    rating: 4.8,
    downloads: 2200,
    popularity: 90,
    createdAt: "2025-07-22",
    updatedAt: "2025-08-10",
    thumbnail: "https://picsum.photos/seed/saas/640/360",
  },
  {
    id: "w2",
    type: "full-website",
    title: "E‑Commerce UI Kit (HTML/CSS)",
    description: "Responsive shop pages: grid, product, cart, checkout.",
    tags: ["HTML", "CSS", "Responsive"],
    language: ["HTML", "CSS"],
    sizeMB: 9,
    price: 29,
    rating: 4.4,
    downloads: 1500,
    popularity: 70,
    createdAt: "2025-05-02",
    updatedAt: "2025-07-28",
    thumbnail: "https://picsum.photos/seed/shop/640/360",
  },
  {
    id: "p1",
    type: "plugin",
    title: "React Charts Suite",
    description: "Lightweight charts with hooks and SSR support.",
    tags: ["Visualization", "Hooks"],
    language: ["React", "TypeScript"],
    sizeMB: 1.6,
    price: 19,
    rating: 4.6,
    downloads: 3800,
    popularity: 95,
    createdAt: "2025-06-01",
    updatedAt: "2025-07-30",
    thumbnail: "https://picsum.photos/seed/charts/640/360",
  },
  {
    id: "p2",
    type: "plugin",
    title: "CSS Animations Pack",
    description: "Utility animations and keyframes for micro‑interactions.",
    tags: ["CSS", "Animations"],
    language: ["CSS"],
    sizeMB: 0.3,
    price: 9,
    rating: 4.2,
    downloads: 8000,
    popularity: 98,
    createdAt: "2025-04-15",
    updatedAt: "2025-05-02",
    thumbnail: "https://picsum.photos/seed/animate/640/360",
  },
  {
    id: "p3",
    type: "plugin",
    title: "HTML Forms Plus",
    description: "Accessible form components, validation helpers.",
    tags: ["A11y", "Forms"],
    language: ["HTML", "JavaScript"],
    sizeMB: 0.8,
    price: 12,
    rating: 4.5,
    downloads: 2100,
    popularity: 77,
    createdAt: "2025-03-20",
    updatedAt: "2025-06-18",
    thumbnail: "https://picsum.photos/seed/forms/640/360",
  },
  {
    id: "b1",
    type: "backend-logic",
    title: "Auth & RBAC (Express)",
    description: "JWT auth, refresh tokens, roles/permissions, rate limit, tests.",
    tags: ["Security", "Express", "RBAC"],
    language: ["Node.js"],
    sizeMB: 6.2,
    price: 39,
    rating: 4.7,
    downloads: 1250,
    popularity: 84,
    createdAt: "2025-07-05",
    updatedAt: "2025-08-01",
    thumbnail: "https://picsum.photos/seed/rbac/640/360",
  },
  {
    id: "b2",
    type: "backend-logic",
    title: "Fast API Starter (Python)",
    description: "FastAPI project with users, email, storage, Docker.",
    tags: ["FastAPI", "Docker", "Postgres"],
    language: ["Python"],
    sizeMB: 15.4,
    price: 45,
    rating: 4.3,
    downloads: 980,
    popularity: 68,
    createdAt: "2025-02-01",
    updatedAt: "2025-07-23",
    thumbnail: "https://picsum.photos/seed/fastapi/640/360",
  },
  {
    id: "p4",
    type: "plugin",
    title: "Vue Table Pro",
    description: "Server‑side pagination, filters, and export for tables.",
    tags: ["Tables", "Export"],
    language: ["Vue"],
    sizeMB: 2.1,
    price: 16,
    rating: 4.1,
    downloads: 1300,
    popularity: 65,
    createdAt: "2025-01-12",
    updatedAt: "2025-03-05",
    thumbnail: "https://picsum.photos/seed/vuetable/640/360",
  },
  {
    id: "w3",
    type: "full-website",
    title: "Portfolio Pro (Vite + React)",
    description: "Animated sections, CMS hooks, and dark mode.",
    tags: ["Portfolio", "Animation", "CMS"],
    language: ["React"],
    sizeMB: 5.7,
    price: 24,
    rating: 4.0,
    downloads: 640,
    popularity: 58,
    createdAt: "2025-06-18",
    updatedAt: "2025-07-19",
    thumbnail: "https://picsum.photos/seed/portfolio/640/360",
  },
];

const LANGUAGES = ["HTML", "CSS", "JavaScript", "React", "Vue", "TypeScript", "Node.js", "Python"];
const TYPES = [
  { key: "full-website", label: "Full Websites" },
  { key: "plugin", label: "Plugins" },
  { key: "backend-logic", label: "Backend Logic" },
];
const SORTS = [
  { key: "newest", label: "Newest" },
  { key: "updated", label: "Recently Updated" },
  { key: "popular", label: "Most Popular" },
  { key: "downloads", label: "Most Downloaded" },
  { key: "rating", label: "Top Rated" },
  { key: "price-asc", label: "Price: Low → High" },
  { key: "price-desc", label: "Price: High → Low" },
  { key: "size-asc", label: "Size: Smallest" },
  { key: "size-desc", label: "Size: Largest" },
];

function useDebounced(value, delay = 300) {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return v;
}

export default function MarketplaceCybersecurity() {
  const [query, setQuery] = useState("");
  const [activeType, setActiveType] = useState("all");
  const [languageFilters, setLanguageFilters] = useState([]);
  const [sort, setSort] = useState("newest");
  const [maxPrice, setMaxPrice] = useState(100);
  const [maxSize, setMaxSize] = useState(100);
  const [minRating, setMinRating] = useState(0);
  const [view, setView] = useState("grid"); // grid | list
  const [onlyFree, setOnlyFree] = useState(false);
  const [tagFilters, setTagFilters] = useState([]);

  const debouncedQuery = useDebounced(query);

  const items = useMemo(() => {
    let data = [...MOCK_ITEMS];

    // Type filter
    if (activeType !== "all") {
      data = data.filter((it) => it.type === activeType);
    }

    // Language filter (any-match)
    if (languageFilters.length) {
      data = data.filter((it) => it.language.some((l) => languageFilters.includes(l)));
    }

    // Tag filter (all must be included)
    if (tagFilters.length) {
      data = data.filter((it) => tagFilters.every((t) => it.tags.includes(t)));
    }

    // Price & size & rating & free toggle
    data = data.filter((it) => it.price <= maxPrice && it.sizeMB <= maxSize && it.rating >= minRating);
    if (onlyFree) data = data.filter((it) => it.price === 0);

    // Text search
    if (debouncedQuery.trim()) {
      const q = debouncedQuery.toLowerCase();
      data = data.filter(
        (it) =>
          it.title.toLowerCase().includes(q) ||
          it.description.toLowerCase().includes(q) ||
          it.tags.join(" ").toLowerCase().includes(q) ||
          it.language.join(" ").toLowerCase().includes(q)
      );
    }

    // Sorting
    const byDate = (k) => (a, b) => new Date(b[k]) - new Date(a[k]);
    switch (sort) {
      case "newest":
        data.sort(byDate("createdAt"));
        break;
      case "updated":
        data.sort(byDate("updatedAt"));
        break;
      case "popular":
        data.sort((a, b) => b.popularity - a.popularity);
        break;
      case "downloads":
        data.sort((a, b) => b.downloads - a.downloads);
        break;
      case "rating":
        data.sort((a, b) => b.rating - a.rating);
        break;
      case "price-asc":
        data.sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        data.sort((a, b) => b.price - a.price);
        break;
      case "size-asc":
        data.sort((a, b) => a.sizeMB - b.sizeMB);
        break;
      case "size-desc":
        data.sort((a, b) => b.sizeMB - a.sizeMB);
        break;
      default:
        break;
    }

    return data;
  }, [activeType, languageFilters, tagFilters, maxPrice, maxSize, minRating, onlyFree, debouncedQuery, sort]);

  // Suggest tags dynamically from dataset
  const allTags = useMemo(() => {
    const set = new Set();
    MOCK_ITEMS.forEach((i) => i.tags.forEach((t) => set.add(t)));
    return Array.from(set).sort();
  }, []);

  // Helper toggles
  const toggleLang = (lang) => {
    setLanguageFilters((prev) => (prev.includes(lang) ? prev.filter((l) => l !== lang) : [...prev, lang]));
  };
  const toggleTag = (tag) => {
    setTagFilters((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));
  };

  return (
    <div className="mp-container">
      {/* Topbar */}
      <header className="mp-topbar">
        <div className="mp-brand">
          <span className="mp-logo">DevBazaar</span>
          <span className="mp-sub">Websites • Plugins • Backend Logic</span>
        </div>
        <div className="mp-search">
          <input
            type="text"
            placeholder="Search templates, plugins, backend starters…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div className="mp-actions">
          <button className="mp-view-btn" aria-pressed={view === "grid"} onClick={() => setView("grid")}>
            Grid
          </button>
          <button className="mp-view-btn" aria-pressed={view === "list"} onClick={() => setView("list")}>
            List
          </button>
        </div>
      </header>

      {/* Category Pills */}
      <nav className="mp-categories">
        <button className={"mp-pill " + (activeType === "all" ? "active" : "")} onClick={() => setActiveType("all")}>
          All
        </button>
        {TYPES.map((t) => (
          <button key={t.key} className={"mp-pill " + (activeType === t.key ? "active" : "")} onClick={() => setActiveType(t.key)}>
            {t.label}
          </button>
        ))}
      </nav>

      {/* Filter bar */}
      <section className="mp-filters">
        <div className="mp-filter-group">
          <label>Sort by</label>
          <select value={sort} onChange={(e) => setSort(e.target.value)}>
            {SORTS.map((s) => (
              <option key={s.key} value={s.key}>
                {s.label}
              </option>
            ))}
          </select>
        </div>

        <div className="mp-filter-group">
          <label>Max Price (${maxPrice})</label>
          <input type="range" min="0" max="200" step="1" value={maxPrice} onChange={(e) => setMaxPrice(Number(e.target.value))} />
        </div>

        <div className="mp-filter-group">
          <label>Max Size ({maxSize} MB)</label>
          <input type="range" min="0" max="100" step="1" value={maxSize} onChange={(e) => setMaxSize(Number(e.target.value))} />
        </div>

        <div className="mp-filter-group">
          <label>Min Rating ({minRating.toFixed(1)})</label>
          <input type="range" min="0" max="5" step="0.1" value={minRating} onChange={(e) => setMinRating(Number(e.target.value))} />
        </div>

        <div className="mp-filter-group mp-langs">
          <label>Languages</label>
          <div className="mp-chip-row">
            {LANGUAGES.map((l) => (
              <button key={l} className={"mp-chip " + (languageFilters.includes(l) ? "active" : "")} onClick={() => toggleLang(l)}>
                {l}
              </button>
            ))}
          </div>
        </div>

        <div className="mp-filter-group mp-tags">
          <label>Tags</label>
          <div className="mp-chip-row">
            {allTags.map((t) => (
              <button key={t} className={"mp-chip " + (tagFilters.includes(t) ? "active" : "")} onClick={() => toggleTag(t)}>
                {t}
              </button>
            ))}
          </div>
        </div>

        <div className="mp-filter-group mp-toggles">
          <label className="mp-switch">
            <input type="checkbox" checked={onlyFree} onChange={(e) => setOnlyFree(e.target.checked)} />
            <span>Only free</span>
          </label>
        </div>
      </section>

      {/* Results */}
      <section className={"mp-results mp-results-" + view}>
        {items.length === 0 && <div className="mp-empty">No items match your filters.</div>}
        {items.map((it) => (
          <article key={it.id} className="mp-card">
            <div className="mp-thumb-wrap">
              <img src={it.thumbnail} alt={it.title} loading="lazy" />
              <div className="mp-type-badge">{it.type.replace("-", " ")}</div>
            </div>
            <div className="mp-card-body">
              <h3 className="mp-title">{it.title}</h3>
              <p className="mp-desc">{it.description}</p>
              <div className="mp-meta">
                <span title="Rating" className="mp-rating">★ {it.rating.toFixed(1)}</span>
                <span title="Downloads" className="mp-dl">⬇ {it.downloads.toLocaleString()}</span>
                <span title="Size" className="mp-size">💾 {it.sizeMB} MB</span>
              </div>
              <div className="mp-tags">
                {it.language.map((l) => (
                  <span key={l} className="mp-badge mp-badge-lang">
                    {l}
                  </span>
                ))}
                {it.tags.map((t) => (
                  <span key={t} className="mp-badge">
                    #{t}
                  </span>
                ))}
              </div>
            </div>
            <div className="mp-card-cta">
              <div className="mp-price">{it.price === 0 ? "Free" : `$${it.price}`}</div>
              <button className="mp-btn">Preview</button>
              <button className="mp-btn mp-btn-primary">Add to Cart</button>
            </div>
          </article>
        ))}
      </section>

      {/* Footer */}
      <footer className="mp-footer">
        <div className="mp-foot-left">
          <strong>Need something custom?</strong> Post a request and get matched with a developer.
        </div>
        <div className="mp-foot-right">
          <button className="mp-btn">Post a Request</button>
          <button className="mp-btn">Contact Support</button>
        </div>
      </footer>
    </div>
  );
}


