import React from "react";
import "./description.css";

const CompanyIntro = () => {
  return (
    <section className="company-intro">
      <h2>About Us</h2>
      <p className="intro-text">
        We are a modern digital solutions company providing **custom websites, plugins, mobile apps,
        game development, cybersecurity solutions, and AI-powered tools**.  
        Our mission is to help businesses and individuals bring their ideas to life using  
        cutting-edge technology, clean design, and performance-focused development.  
      </p>

      <p className="intro-text">
        Whether you need a **responsive business website**, a **feature-rich mobile app**,  
        or **secure cloud-based services**, we have the expertise to deliver.  
        We pride ourselves on delivering **fast, scalable, and user-friendly solutions**  
        tailored to your needs.
      </p>

      <p className="intro-text highlight">
        🚀 Let's turn your vision into reality!
      </p>
    </section>
  );
};

export default CompanyIntro;
