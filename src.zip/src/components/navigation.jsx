import React, { useState } from "react";
import "./navigation.css";
import {
  FaHome,
  FaInfoCircle,
  FaDollarSign,
  FaCogs,
  FaSignOutAlt,
  FaBars,
  FaTimes,
  FaWrench,
} from "react-icons/fa";

function Navigation() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const toggleMenu = () => setMenuOpen(!menuOpen);
  const toggleSettings = () => setSettingsOpen(!settingsOpen);
  const closeMenu = () => {
    setMenuOpen(false);
    setSettingsOpen(false);
  };

  return (
    <nav className="navbar">
      <div className="logo">AppSeller</div>

      <div className={`nav-links ${menuOpen ? "open" : ""}`}>
        <a href="#home" onClick={closeMenu}><FaHome /> Home</a>
        <a href="#about" onClick={closeMenu}><FaInfoCircle /> About</a>
        <a href="#services" onClick={closeMenu}><FaWrench /> Services</a>
        <a href="#pricing" onClick={closeMenu}><FaDollarSign /> Pricing</a>

        <div className="dropdown">
          <button onClick={toggleSettings} className="dropdown-toggle">
            <FaCogs /> Settings
          </button>
          <div className={`dropdown-menu ${settingsOpen ? "show" : ""}`}>
            <a href="#profile" onClick={closeMenu}>Profile</a>
            <a href="#preferences" onClick={closeMenu}>Preferences</a>
          </div>
        </div>

        <a href="#logout" onClick={closeMenu}><FaSignOutAlt /> Logout</a>
      </div>

      <button className="hamburger" onClick={toggleMenu}>
        {menuOpen ? <FaTimes /> : <FaBars />}
      </button>
    </nav>
  );
}

export default Navigation;
