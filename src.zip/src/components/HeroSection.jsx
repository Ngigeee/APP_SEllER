import React from "react";
import "./HeroSection.css";

function Hero() {
  return (
    <section className="hero-section">
      <div className="hero-content">
        <h1>Welcome to AppSeller</h1>
        <p>Your ultimate platform for selling smarter and faster</p>
        <a href="#pricing" className="hero-btn">View Pricing</a>
      </div>
    </section>
  );
}

export default Hero;
