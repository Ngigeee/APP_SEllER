import React, { useState } from 'react';
import './ourProducts.css';
import Modal from "../components/overlayModal";
import ProductDetails from "../components/productDetails";
import products from "../data/products";

const OurProducts = () => {
  const [showModal, setShowModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);

  const openModal = (product) => {
    setSelectedProduct(product);
    setShowModal(true);
  };

  return (
    <section className="our-products">
      <h2>Our Products</h2>
      <div className="product-grid">
        {products.map((product, index) => (
          <div className="product-card" key={index} onClick={() => openModal(product)}>
            <img src={product.image} alt={product.title} />
            <p className="product-description">{product.description}</p>
            <div className="product-title">{product.title}</div>
          </div>
        ))}
      </div>

      <Modal isOpen={showModal} onClose={() => setShowModal(false)}>
        <ProductDetails product={selectedProduct} />
      </Modal>
    </section>
  );
};

export default OurProducts;
