import React from "react";
import "./pricing.css";
import managementImage from "../assets/management.png"; // Replace with your actual image path

const PricingSection = () => {
  const plans = [
    {
      title: "Basic",
      price: "Ksh99",
      features: ["Feature 1", "Feature 2", "Feature 3"],
    },
    {
      title: "Standard",
      price: "$199",
      features: ["Feature 1", "Feature 2", "Feature 3"],
    },
    {
      title: "Premium",
      price: "$299",
      features: ["Feature 1", "Feature 2", "Feature 3"],
    },
  ];

  return (
    <section className="pricing-section">
      <h2 className="pricing-title">Pricing</h2>
      <div className="pricing-container">
        {plans.map((plan, index) => (
          <div key={index} className="pricing-card">
            <h3>{plan.title}</h3>
            <p className="price">{plan.price}</p>
            <ul>
              {plan.features.map((feature, i) => (
                <li key={i}>✓ {feature}</li>
              ))}
            </ul>
            <button className="get-started-btn">Get Started</button>
          </div>
        ))}

        <div className="management-section">
          <img src={managementImage} alt="Management Dashboard" />
          <h3>Management</h3>
          <p>
            Efficiency tool for organizing and optimizing your business
            activities.
          </p>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
