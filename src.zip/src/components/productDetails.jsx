import React from "react";
import "./productDetails.css"; // Import the external CSS file
import { Link } from "react-router-dom";

// ...



const ProductDetails = ({ product }) => {
  if (!product) return null;

  return (
    // Card container using the new CSS class
    <div className="product-details-card">
      <h2 className="product-details-title">{product.title}</h2>
      <p className="product-details-description">{product.description}</p>

      {product.features && product.features.length > 0 && (
        <div className="mb-4">
          <h3 className="section-heading">Features:</h3>
          <ul className="features-list">
            {product.features.map((f, i) => (
              <li key={i} className="feature-item">
                <span className="check-icon">✔</span> {f}
              </li>
            ))}
          </ul>
        </div>
      )}

      {product.screenshots?.length > 0 && (
        <div className="mb-4">
          <h3 className="section-heading">Screenshots:</h3>
           <div className="mb-5">
            {product.screenshots.map((src, idx) => (
          <div className="screenshots-grid">
          
              <img
                key={idx}
                src={src}
                alt={`${product.title} screenshot ${idx + 1}`}
                className="screenshot-image"
                // Fallback for broken images
                onError={(e) => { e.target.onerror = null; e.target.src = `https://placehold.co/400x300/cccccc/333333?text=Image+Error`; }}
              />
            <div className="actions-container">
        <a
          href={product.demoLink}
          target="_blank"
          rel="noopener noreferrer"
          className="action-button demo-button"
        >
          <span>🔗</span> Live Demo
        </a>
        <a
          href={product.buyLink}
          target="_blank"
          rel="noopener noreferrer"
          className="action-button buy-button"
        >
          <span>🛒</span> Buy Now
        </a>
      </div>
          </div>
          ))}
          <Link to={`/product/${product.id}`} className="seeMore">Read More</Link>

          </div>
        </div>
      )}

      
    </div>
  );
};

export default ProductDetails;
