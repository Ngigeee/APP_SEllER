import React from 'react';
import './testimonial.css';

const TestimonialSection = () => {
  return (
    <section className="testimonials-section">
      <h2 className="testimonials-title">What Our Clients Say</h2>
      <div className="testimonials-container">
        <div className="testimonial-card">
          <p className="testimonial-text">
            “This service has changed how we do business. Professional, reliable, and fast.”
          </p>
          <div className="testimonial-author">
            <img src="/images/client1.jpg" alt="Client 1" />
            <div>
              <h4>Jane Doe</h4>
              <span>CEO, GreenTech</span>
            </div>
          </div>
        </div>

        <div className="testimonial-card">
          <p className="testimonial-text">
            “Absolutely wonderful! We’ve seen growth since implementing their tools.”
          </p>
          <div className="testimonial-author">
            <img src="/images/client2.jpg" alt="Client 2" />
            <div>
              <h4>John Smith</h4>
              <span>Marketing Lead, EcoGrow</span>
            </div>
          </div>
        </div>

        <div className="testimonial-card">
          <p className="testimonial-text">
            “Their team is friendly and their system is top-notch. Highly recommended.”
          </p>
          <div className="testimonial-author">
            <img src="/images/client3.jpg" alt="Client 3" />
            <div>
              <h4>Mary Wanjiku</h4>
              <span>Founder, MtaaTech</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialSection;
