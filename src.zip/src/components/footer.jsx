import React from "react";
import "./footer.css";
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin, FaYoutube } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="footer-container">
        
        {/* Company Info */}
        <div className="footer-section company-info">
          <h2 className="footer-logo">TechSolutions</h2>
          <p>
            We build websites, mobile apps, plugins, and AI-powered solutions tailored to your needs.
            Secure, fast, and user-friendly digital products to help your business thrive.
          </p>
        </div>

        {/* Navigation Links */}
        <div className="footer-section">
          <h3>Quick Links</h3>
          <ul>
            <li><a href="/about">About Us</a></li>
            <li><a href="/products">Our Products</a></li>
            <li><a href="/contact">Contact</a></li>
            <li><a href="/privacy">Privacy Policy</a></li>
          </ul>
        </div>

        {/* Social Media */}
        <div className="footer-section">
          <h3>Follow Us</h3>
          <ul className="social-links">
            <li><FaFacebook /> Facebook</li>
            <li><FaTwitter /> Twitter</li>
            <li><FaInstagram /> Instagram</li>
            <li><FaLinkedin /> LinkedIn</li>
            <li><FaYoutube /> YouTube</li>
          </ul>
        </div>

        {/* Subscribe */}
        <div className="footer-section subscribe">
          <h3>Subscribe</h3>
          <p>Get updates about our latest products and offers.</p>
          <form className="subscribe-form">
            <input type="email" placeholder="Enter your email" />
            <button type="submit">Subscribe</button>
          </form>
        </div>

        {/* Contact Info */}
        <div className="footer-section contact-info">
          <h3>Contact Us</h3>
          <p>Email: info@techsolutions.com</p>
          <p>Phone: +254 712 345 678</p>
          <p>Location: Nairobi, Kenya</p>
        </div>

      </div>

      {/* Footer Bottom */}
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} TechSolutions. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
