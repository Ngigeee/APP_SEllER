import React from "react";
import "./ContentSection.css";

const ContentSection = () => {
  return (
    <section className="content">
      <div className="card">Card 1</div>
      <div className="card">Card 2</div>
      <div className="card">Card 3</div>
    </section>
  );
};

export default ContentSection;
