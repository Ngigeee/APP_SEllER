import React from "react";
import { useParams } from "react-router-dom";

import MarketplaceWebsite from "../components/websitemarket";
import MarketplaceApp from "../components/appmarket";
import MarketplaceTemplates from "../components/templatesmarket";
import MarketplaceGameDev from "../components/gamesmarket";
import MarketplaceCybersecurity from "../components/cybersecuritymarket";
import MarketplaceAI from "../components/aimarket";

export default function ProductPage() {
  const { id } = useParams();

  switch (id) {
    case "websites":
      return <MarketplaceWebsite />;
    case "apps":
      return <MarketplaceApp />;
    case "templates":
      return <MarketplaceTemplates />;
    case "game-dev":
      return <MarketplaceGameDev />;
    case "cybersecurity":
      return <MarketplaceCybersecurity />;
    case "ai":
      return <MarketplaceAI />;
    default:
      return <h2>Product not found</h2>;
  }
}
