import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navigation from "./components/navigation";
import Hero from "./components/HeroSection";
import OurProducts from "./components/ourProducts";
import PricingSection from "./components/pricing";
import TestimonialSection from "./components/testimonial";
import ProductPage from "./pages/ProductPage";
import CompanyIntro from "./components/description";
import Footer from "./components/footer";

function App() {
  return (
    <Router>
      
      <Routes>
        <Route
          path="/"
          element={
            <>
            <Navigation />
              <Hero />
              <OurProducts />
              <CompanyIntro />
              <PricingSection />
              <TestimonialSection />
              <Footer />
            </>
          }
        />
        <Route path="/product/:id" element={<ProductPage />} />
      </Routes>
    </Router>
  );
}

export default App;
