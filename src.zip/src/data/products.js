// src/data/products.js
const products = [
  {
    id: "websites",
    title: "Websites",
    image: "/assets/web.png",
    description: "Custom responsive websites built with modern frameworks for all devices.",
    features: ["Responsive", "SEO-friendly", "Modern UI", "Fast Loading"],
    demoLink: "https://example.com/website-demo",
    buyLink: "https://example.com/buy-websites",
    screenshots: [
      "/assets/web.png",
      "/assets/web.png"
    ]
  },
  {
   id: "apps",
    title: "Mobile Apps",
    image: "/assets/android.png",
    description: "Android & iOS apps tailored for performance, usability, and scalability.",
    features: ["Cross-platform", "Native Performance", "Play Store Ready"],
    demoLink: "https://example.com/app-demo",
    buyLink: "https://example.com/buy-apps",
    seeMore: "appmarket.jsx",
    screenshots: [
      "/assets/android.png",
      "/assets/android.png"
    ]
  },
  {
   id: "templates",
    title: "Templates",
    image: "/assets/web-design.png",
    description: "Pre-built professional templates for faster development and deployment.",
    features: ["Modern", "Customizable", "Mobile-first"],
    demoLink: "https://example.com/templates-demo",
    buyLink: "https://example.com/buy-templates",
    seeMore: "https://example.com/buy-security",
    screenshots: [
      "/assets/web-design.png",
       "/assets/web-design.png"
    ]
  },
  {
   id: "game dev",
    title: "Game Dev",
    image: "/assets/house.png",
    description: "2D & 3D games with stunning graphics and smooth gameplay using Unity or WebGL.",
    features: ["Unity 3D", "Multiplatform", "Smooth Gameplay"],
    demoLink: "https://example.com/game-demo",
    buyLink: "https://example.com/buy-games",
    seeMore: "https://example.com/buy-security",
    screenshots: [
      "/assets/house.png",
      "/assets/house.png",
      "/assets/house.png",
      "/assets/house.png"
    ]
  },
  { 
    id: "cybersecurity",
    title: "Cybersecurity",
    image: "/assets/cyber-security.png",
    description: "Advanced tools and services for securing networks, apps, and data.",
    features: ["Penetration Testing", "Vulnerability Scans", "Data Protection"],
    demoLink: "https://example.com/security-demo",
    buyLink: "https://example.com/buy-security",
    seeMore: "https://example.com/buy-security",
    screenshots: [
    "/assets/cyber-security.png",
    "/assets/cyber-security.png",
    "/assets/cyber-security.png",
    "/assets/cyber-security.png"]
  },
  {
    id: "ai",
    title: "AI/ML Tools",
    image: "/assets/ai.png",
    description: "Smart AI solutions, from chatbots to predictive analytics and automation.",
    features: ["Chatbots", "Data Modeling", "NLP", "Automation"],
    demoLink: "https://example.com/ai-demo",
    buyLink: "https://example.com/buy-ai",
    seeMore: "https://example.com/buy-security",
    screenshots: [
      "/assets/ai.png",
      "/assets/ai.png",
      "/assets/ai.png",
      "/assets/ai.png"
    ]
  }
];

export default products;
