{
  id: 1,
  title: "Portfolio Website",
  description: "A sleek personal portfolio template.",
  type: "website", // determines which page
  features: ["Responsive", "SEO Friendly"],
  screenshots: ["/img/site1.png", "/img/site2.png"],
  demoLink: "https://demo.com",
  buyLink: "https://buy.com"
}
